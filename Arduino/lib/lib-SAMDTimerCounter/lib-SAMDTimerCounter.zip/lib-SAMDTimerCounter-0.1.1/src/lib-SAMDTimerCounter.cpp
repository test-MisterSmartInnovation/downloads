#include "lib-SAMDTimerCounter.h"

/*
 * *******************************************************************************
 * DEFINE CALLBACK & HANDLERS FUNCTIONS 
 * *******************************************************************************
 */

SAMDTimerCallback TCC0_callback;
SAMDTimerCallback TCC1_callback;
SAMDTimerCallback TCC2_callback;
SAMDTimerCallback TC3_callback; 
SAMDTimerCallback TC4_callback;
SAMDTimerCallback TC5_callback;


void TCC0_Handler()
{
  // get timer struct
  Tcc* TC = (Tcc*) TCC0;
  
  // If the compare register matching the timer count, trigger this interrupt
  if (TC->INTFLAG.bit.MC0 == 1) 
  {  
    // A compare to cc0 caused the interrupt
    TC->INTFLAG.bit.MC0 = 1;    // writing a one clears the flag ovf flag
  }
  if (TC->INTFLAG.bit.OVF == 1) 
  {
    (*TCC0_callback)();
    
    TC->INTFLAG.bit.OVF = 1;
  }
}
  
void TCC1_Handler()
{
  // get timer struct
  Tcc* TC = (Tcc*) TCC1;
  
  // If the compare register matching the timer count, trigger this interrupt
  if (TC->INTFLAG.bit.MC0 == 1) 
  {  
    // A compare to cc0 caused the interrupt
    TC->INTFLAG.bit.MC0 = 1;    // writing a one clears the flag ovf flag
  }
  if (TC->INTFLAG.bit.OVF == 1) 
  {
    (*TCC1_callback)();
    
    TC->INTFLAG.bit.OVF = 1;
  }
}

void TCC2_Handler()
{
  // get timer struct
  Tcc* TC = (Tcc*) TCC2;
  
  // If the compare register matching the timer count, trigger this interrupt
  if (TC->INTFLAG.bit.MC0 == 1) 
  {  
    // A compare to cc0 caused the interrupt
    TC->INTFLAG.bit.MC0 = 1;    // writing a one clears the flag ovf flag
  }
  if (TC->INTFLAG.bit.OVF == 1) 
  {
    (*TCC2_callback)();
    
    TC->INTFLAG.bit.OVF = 1;
  }
}

void TC3_Handler()
{
  // get timer struct
  TcCount16* TC = (TcCount16*) TC3;
  
  // If the compare register matching the timer count, trigger this interrupt
  if (TC->INTFLAG.bit.MC0 == 1) 
  {
    TC->INTFLAG.bit.MC0 = 1;
    (*TC3_callback)();
  }
}

void TC4_Handler()
{
  // get timer struct
  TcCount16* TC = (TcCount16*) TC4;
  
  // If the compare register matching the timer count, trigger this interrupt
  if (TC->INTFLAG.bit.MC0 == 1) 
  {
    TC->INTFLAG.bit.MC0 = 1;
    (*TC4_callback)();
  }
}

void TC5_Handler()
{
  // get timer struct
  TcCount16* TC = (TcCount16*) TC5;
  
  // If the compare register matching the timer count, trigger this interrupt
  if (TC->INTFLAG.bit.MC0 == 1) 
  {
    TC->INTFLAG.bit.MC0 = 1;
    (*TC5_callback)();
  }
}


/*
 * *******************************************************************************
 * SAMDTimerCounter
 * *******************************************************************************
 */

/*-------------------------------------------------------------------------------
 * Constructor
 */

SAMDTimerCounter::SAMDTimerCounter(const SAMDTimerNumber& timer_num)
{
  timer_num_ = timer_num;
  
  setTimerType();
  setTimerPtr();

  begin();

  this->busy_   = false;
  this->flag_   = false;
  this->period_ = 0;
}
    

SAMDTimerCounter::~SAMDTimerCounter() {}


/*-------------------------------------------------------------------------------
 * Public
 */
void SAMDTimerCounter::attachCallback(SAMDTimerCallback callback)
{
  //callback_     = callback;
  if (timer_num_ == TIMER_TCC0)
    TCC0_callback  = callback;
  else if (timer_num_ == TIMER_TCC1)
    TCC1_callback  = callback;
  else if (timer_num_ == TIMER_TCC2)
    TCC2_callback  = callback;
  else if (timer_num_ == TIMER_TC3)
      TC3_callback  = callback;
  else if (timer_num_ == TIMER_TC4)
    TC4_callback  = callback;
  else if (timer_num_ == TIMER_TC5)
    TC5_callback  = callback;
}


void SAMDTimerCounter::setPeriod(const int & period)
{
  this->period_ = period;
  if (timer_type_ == TYPE_TCCx)
    setPeriodTCCx(this->period_);
  else if (timer_type_ == TYPE_TCx)
    setPeriodTCx(this->period_);
}


int SAMDTimerCounter::getPeriod(void)
{
  return this->period_;
}


bool SAMDTimerCounter::start(void)
{
  this->busy_ = true;
  this->flag_ = true;
  if (timer_type_ == TYPE_TCCx)
    enableTCCx();
  else if (timer_type_ == TYPE_TCx)
    enableTCx();
  
  return true;
}


bool SAMDTimerCounter::stop(void)
{
  if (timer_type_ == TYPE_TCCx)
    disableTCCx();
  else if (timer_type_ == TYPE_TCx)
    disableTCx();
  
  this->busy_ = false;
  this->flag_ = false;

  return true;
}


bool SAMDTimerCounter::reset(void)
{
  if (timer_type_ == TYPE_TCCx)
    resetTCCx();
  else if (timer_type_ == TYPE_TCx)
    resetTCx();

  return true;
}

bool SAMDTimerCounter::isBusy()
{
  return this->busy_;
}

bool SAMDTimerCounter::toggle()
{
  this->flag_ = this->flag_ ^ 1;
  return this->flag_;
}


/*-------------------------------------------------------------------------------
 * Private
 */
void SAMDTimerCounter::setTimerType()
{
  timer_type_ = TYPE_ERR;
  if
  (
    (timer_num_ == TIMER_TCC0) ||
    (timer_num_ == TIMER_TCC1) ||
    (timer_num_ == TIMER_TCC2)
  )
    timer_type_ = TYPE_TCCx;
  else if
  (
    (timer_num_ == TIMER_TC3) || 
    (timer_num_ == TIMER_TC4) || 
    (timer_num_ == TIMER_TC5)
  )
    timer_type_ = TYPE_TCx;
}


void SAMDTimerCounter::setTimerPtr()
{
  timer_ptr_ = NULL;
  if (timer_num_ == TIMER_TCC0)
    timer_ptr_ = (Tcc*) TCC0;
  else if (timer_num_ == TIMER_TCC1)
    timer_ptr_ = (Tcc*) TCC1;
  else if (timer_num_ == TIMER_TCC2)
    timer_ptr_ = (Tcc*) TCC2;
  else if (timer_num_ == TIMER_TC3)
    timer_ptr_ = (TcCount16*) TC3;
  else if (timer_num_ == TIMER_TC4)
    timer_ptr_ = (TcCount16*) TC4;
  else if (timer_num_ == TIMER_TC5)
    timer_ptr_ = (TcCount16*) TC5;
}


void SAMDTimerCounter::setClockSource()
{
  REG_GCLK_CLKCTRL = (uint16_t) (GCLK_CLKCTRL_CLKEN | GCLK_CLKCTRL_GEN_GCLK3 | GCLK_CLKCTRL_ID (TC_GCLK_ID[timer_num_]));
  /* wait for sync */
  while ( GCLK->STATUS.bit.SYNCBUSY == 1 );
}


void SAMDTimerCounter::setPrescalerTCCx()
{
  TCCx->CTRLA.reg |= TCC_CTRLA_PRESCALER_DIV8;
}


void SAMDTimerCounter::setPrescalerTCx()
{
  TCx->CTRLA.reg |= TC_CTRLA_PRESCALER_DIV8;
  while (TCx->STATUS.bit.SYNCBUSY == 1);
}


void SAMDTimerCounter::setModeTCCx()
{
  // Use match mode so that the timer counter resets when the count matches the compare register
  TCCx->WAVE.reg |= TCC_WAVE_WAVEGEN_NFRQ;   // Set wave form configuration 
  while (TCCx->SYNCBUSY.bit.WAVE == 1); // wait for sync 
  // Enable the compare interrupt
  TCCx->INTENSET.reg = 0;
  TCCx->INTENSET.bit.OVF = 1;
  TCCx->INTENSET.bit.MC0 = 1;
}


void SAMDTimerCounter::setModeTCx()
{
  // Use the 16-bit timer
  TCx->CTRLA.reg |= TC_CTRLA_MODE_COUNT16;
  /* wait for sync */
  while (TCx->STATUS.bit.SYNCBUSY == 1);
  // Use match mode so that the timer counter resets when the count matches the compare register
  TCx->CTRLA.reg |= TC_CTRLA_WAVEGEN_MFRQ;
  /* wait for sync */
  while (TCx->STATUS.bit.SYNCBUSY == 1);
  TCx->INTENSET.reg = 0;
  TCx->INTENSET.bit.MC0 = 1;
}


void SAMDTimerCounter::setPeriodTCCx(const int &period)
{
  TCCx->PER.reg = period - 1; 
  while (TCCx->SYNCBUSY.bit.PER == 1);
  // Make sure the count is in a proportional position to where it was
  // to prevent any jitter or disconnect when changing the compare value.
  TCCx->CC[0].reg = 0xFFF;
  while (TCCx->SYNCBUSY.bit.CC0 == 1);
}


void SAMDTimerCounter::setPeriodTCx(const int &period)
{
  // Make sure the count is in a proportional position to where it was
  // to prevent any jitter or disconnect when changing the compare value.
  TCx->COUNT.reg = map(TCx->COUNT.reg, 0, TCx->CC[0].reg, 0, period);
  TCx->CC[0].reg = period -1;
  while (TCx->STATUS.bit.SYNCBUSY == 1);
}


void SAMDTimerCounter::enableTCCx()
{
  TCCx->CTRLA.reg |= TCC_CTRLA_ENABLE;
  while (TCCx->SYNCBUSY.bit.ENABLE == 1);
}


void SAMDTimerCounter::enableTCx()
{
  TCx->CTRLA.reg |= TC_CTRLA_ENABLE;
  while ( GCLK->STATUS.bit.SYNCBUSY == 1 );
}


void SAMDTimerCounter::disableTCCx()
{
  TCCx->CTRLA.reg &= ~TCC_CTRLA_ENABLE;
  while (TCCx->SYNCBUSY.bit.ENABLE == 1);
}


void SAMDTimerCounter::disableTCx()
{
  TCx->CTRLA.reg &= ~TC_CTRLA_ENABLE;
  while ( GCLK->STATUS.bit.SYNCBUSY == 1 );
}


void SAMDTimerCounter::resetTCCx()
{
  TCCx->INTFLAG.bit.MC0 = 1;
  TCCx->INTFLAG.bit.OVF = 1;
}


void SAMDTimerCounter::resetTCx()
{
  TCx->INTFLAG.bit.MC0 = 1;
}


void SAMDTimerCounter::attachInterrupt()
{
  // Disable Interrupt
  NVIC_EnableIRQ(TIMER_IRQ[timer_num_]);      
}


void SAMDTimerCounter::detachInterrupt()
{
  // Disable Interrupt
  NVIC_DisableIRQ(TIMER_IRQ[timer_num_]);     
}


bool SAMDTimerCounter::begin()
{
  setClockSource();
  if (timer_type_ == TYPE_TCCx)
  {
    disableTCCx();
    setPrescalerTCCx();
    setModeTCCx();
  }
  else if (timer_type_ == TYPE_TCx)
  {
    disableTCx();
    setPrescalerTCx();
    setModeTCx();
  }
  attachInterrupt();
  return true;
}
