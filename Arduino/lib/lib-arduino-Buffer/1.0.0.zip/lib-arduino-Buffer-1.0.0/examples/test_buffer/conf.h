/* ----------------------------------
* Explicitly value type for example 
*/
#define BUFFER_VALUE_TYPE int