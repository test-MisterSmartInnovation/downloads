#include "lib-arduino-Buffer.h"

/* ----------------------------------
* Explicitly value type for example 
*/
#define BUFFER_VALUE_TYPE int

/* ---------------------------
* Explicitly instantiate the tamplate 
*/
template class Buffer<BUFFER_VALUE_TYPE>;