#include "lib-arduino-Buffer.h"

/*
 * *******************************************************************************
 * Buffer
 * *******************************************************************************
 */

/* ---------------------------------------
* Constructor Destructor
*/
template <typename T> Buffer<T>::Buffer(int size)
{
  this->size_ = size;
  this->front_ = this->back_ = 0;
  this->values_ = new T [size];
}

template <typename T> Buffer<T>::~Buffer()
{
  delete [] this->values_;
}

/*-------------------------------------------------------------------------------
 * Public
 */
template <typename T> bool Buffer<T>::isEmpty()
{
  /* */
  return (this->back_ == this->front_);
}


template <typename T> bool Buffer<T>::isFull()
{
  /* */
  return (this->back_ == this->size_);
}


template <typename T> bool Buffer<T>::addValue(T value)
{
  this->values_[this->back_] = value;
  this->back_++;
  /* */
  return true;
}


template <typename T> T Buffer<T>::getFirst()
{
  /* get first */
  T value = this->values_[this->front_];
  /* shift array */
  for (int i = 0; i < this->back_ - 1; i++)
    this->values_[i] = this->values_[i+1];
  /* decreas back */
  this->back_--;
  /* */
  return value;
}


template <typename T> int Buffer<T>::getSize()
{
  /* */
  return this->back_;
}


template <typename T> bool Buffer<T>::clear()
{
  this->back_ = 0;
  /* */
  return true;
}
