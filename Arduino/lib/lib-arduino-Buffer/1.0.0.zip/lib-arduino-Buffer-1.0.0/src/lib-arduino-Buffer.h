#pragma once
/* Buffer use queue: operate as FIFO
*
*/

#ifndef LIB_ARDUINO_BUFFER_H
#define LIB_ARDUINO_BUFFER_H


/*
 * *******************************************************************************
 * Buffer
 * *******************************************************************************
 */
template <typename T> class Buffer
{
  /*-------------------------------------------------------------------------------
   * Public
   */
  public:
    /* Constructor - Distructor */
    Buffer(int size);
    ~Buffer();
    /* Attributes */
    /* Methods */ 
    bool isEmpty();
    bool isFull();
    bool addValue(T value); /* push back */
    T    getFirst();        /* pop front */
    int  getSize();
    bool clear();

  /*-------------------------------------------------------------------------------
   * Private
   */    
  private:
    /* Attributes */
    int front_;
    int back_;
    int size_;
    T* values_;
    /* Methods */ 
};

#endif // LIB_ARDUINO_BUFFER_H