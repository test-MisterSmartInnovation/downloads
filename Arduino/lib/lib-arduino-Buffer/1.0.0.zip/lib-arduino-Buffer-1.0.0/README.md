# Buffer
This library allows you to add value in a buffer as a FIFO queue.
