# StepperCtrl
This library allows you to control unipolar or bipolar stepper motors in position and speed mode. To use it you will need a stepper motor, and the appropriate hardware to control it
