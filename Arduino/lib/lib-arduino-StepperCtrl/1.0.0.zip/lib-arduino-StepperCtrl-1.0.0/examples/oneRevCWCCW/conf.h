#define STEP_PER_REVOLUTION 200
#define PIN_DIR 2
#define PIN_PUL 3

#define STEPS           200
#define HALF_PERIOD_US 1000
