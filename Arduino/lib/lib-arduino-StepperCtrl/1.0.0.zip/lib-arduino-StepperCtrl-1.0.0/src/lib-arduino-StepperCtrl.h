#pragma once

#include "Arduino.h"

#ifndef LIB_ARDUINO_STEPPER_CTRL_H
#define LIB_ARDUINO_STEPPER_CTRL_H


/*
 * *******************************************************************************
 * StepperCtrl
 * *******************************************************************************
 */
class StepperCtrl {
  /*-------------------------------------------------------------------------------
   * Public
   */
  public:
    /* wise */
    typedef enum
    {
      CW  = LOW,
      CCW = HIGH,
    } WISE;
    /* Constructor */
    StepperCtrl(int, int, int);
    ~StepperCtrl();
    /* Attributes */
    /* Methods */
    int  getDirection(void);
    bool setDirection(WISE);
    bool isBusy      (void);
    bool step        (int) ;
    bool pulseStep   (void);
    int  getStepNum  (void);
    
  /*-------------------------------------------------------------------------------
   * Private
   */    
  private:
    /* Attributes */
    int  steps_per_revolution_; /* total number of steps this motor can take */
    int  pin_count_           ; /* how many pins are in use */
    int  wise_                ; /* Direction of rotation */
    int  motor_pin_[4]        ;
    int  steps_to_move_       ;
    int  step_num_            ;
    int  pulse_status_        ;
    bool busy_                ;
    /* Methods */
    bool begin          (void)   ;
    bool pulse          (void)   ;
    bool stepCount      (void)   ;
    bool isBusyPulseStep(void)   ;
    bool setOutputPins  (uint8_t);
};

#endif // LIB_ARDUINO_STEPPER_CTRL_H