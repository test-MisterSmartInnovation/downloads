#include "lib-arduino-StepperCtrl.h"

/*
 * *******************************************************************************
 * StepperCtrl
 * *******************************************************************************
 */

/*-------------------------------------------------------------------------------
 * Constructor Destructor
 */
StepperCtrl::StepperCtrl(int steps_per_revolution, int dir_pin, int step_pin)
{
  this->steps_per_revolution_ = steps_per_revolution; // total number of steps for this motor
  this->step_angle_ = TWO_PI / (double)steps_per_revolution; /* step angle */
  // Arduino pins for the motor control connection:
  this->motor_pin_[0] = dir_pin;
  this->motor_pin_[1] = step_pin;
  this->motor_pin_[2] = -1;
  this->motor_pin_[3] = -1;
  // pin_count is used by the stepMotor() method:
  this->pin_count_ = 2;
  this->begin();
}


StepperCtrl::~StepperCtrl() {};


/*-------------------------------------------------------------------------------
 * Public
 */
bool StepperCtrl::setDirection(StepperCtrl::WISE wise)
{
  /* */
  this->wise_ = wise;
  /* */
  digitalWrite(this->motor_pin_[0], this->wise_);
  /* */
  return true;
}


int StepperCtrl::getDirection()
{
  /* */
  return this->wise_;
}


bool StepperCtrl::isBusy(void)
{
  /* */
  return this->busy_;
}


//bool StepperCtrl::step(int steps)
//{
//  /* check if step is null */
//  if (steps != 0)
//  {
//    /* start condition */
//    this->steps_to_move_ = abs(steps);
//    this->busy_          = true;
//    this->pulse_status_  = LOW;
//    this->setDirection((steps > 0 ? StepperCtrl::CW : StepperCtrl::CCW));
//    /*start with pulse high*/
//    this->pulse();
//  }
//  /* */
//  return true;
//}


bool StepperCtrl::pulseStep(void)
{
  /* check condition counter */
  this->busy_ = this->pulse();
  if (!this->busy_)
    this->stepCount();
  /* */
  return true;
}


int StepperCtrl::getStepNum(void)
{
  int tot_step = 0;
  /* check if revolutions_ is < 0 < */
  if (this->revolutions_)
    tot_step = this->revolutions_ * this->steps_per_revolution_;
  tot_step += this->step_num_;
  /* */
  return tot_step;
}


bool StepperCtrl::setStepNum(int step_num)
{
  /* set step_num and */
  this->revolutions_ = step_num / this->steps_per_revolution_ ; 
  this->step_num_    = step_num % this->steps_per_revolution_ ; 
  /* */
  return true;
}


int StepperCtrl::getSPR(void)
{
  /* */
  return this->steps_per_revolution_;
}


double StepperCtrl::getStepAngle(void)
{
  /* */
  return this->step_angle_;
}



/*-------------------------------------------------------------------------------
 * Private
 */
bool StepperCtrl::begin(void)
{
  /* common attribute */
  //this->steps_to_move_ = 0;
  this->step_num_      = 0;
  this->busy_          = false;
  this->pulse_status_  = LOW;
  /* setup the pins on the microcontroller: */ 
  for (int i = 0; i < this->pin_count_; i++)
    pinMode(this->motor_pin_[i], OUTPUT);
  /* */
  return true;
}


bool StepperCtrl::stepCount(void)
{
  /* direction CW: increase counter */
  int increment;
  (this->getDirection() == StepperCtrl::CW) ? (increment = -1) : (increment = 1);
  /* update num step */
  this->step_num_ = this->step_num_ + increment;
  /* update revolutions */
  if (abs(this->step_num_) == this->steps_per_revolution_)
  {
    this->step_num_ = 0;
    this->revolutions_ = this->revolutions_ + increment;
  }
  /* */
  return true;
}


//bool StepperCtrl::isBusyPulseStep(void)
//{
//  /* update step done */
//  this->steps_to_move_--;
//  /* check if terminate */
//  if (!this->steps_to_move_)
//    this->busy_ = false;
//  /* */
//  return this->busy_;
//}


bool StepperCtrl::pulse()
{
  this->pulse_status_ = this->pulse_status_ ^ 1;
  digitalWrite(this->motor_pin_[1], this->pulse_status_);
  /* */
  return this->pulse_status_;
}


bool StepperCtrl::setOutputPins(uint8_t mask)
{
  for (int i = 0; i < this->pin_count_; i++)
    digitalWrite(this->motor_pin_[i], (mask & (1 << i)) ? (HIGH) : (LOW));
  /* */
  return true;
}