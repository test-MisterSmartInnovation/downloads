/* stepper */
#define STEP_PER_REVOLUTION 200
//#define PIN_DIR  A4
//#define PIN_STEP A3
#define PIN_DIR  D1
#define PIN_STEP D0
/* gearbox */
#define GEAR_RATIO 10
/* */
#define ONE_REVOLUTION STEP_PER_REVOLUTION*GEAR_RATIO

/* timer */
#define START_PERIOD_US 1500 // 100 RPM (10 RPM with GEAR_RATIO)
#define MIN_PERIOD_US    500 // 300 RPM (30 RPM with GEAR_RATIO)