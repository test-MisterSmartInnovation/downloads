/* stepper */
#define STEP_PER_REVOLUTION 200
#define PIN_DIR  A4
#define PIN_STEP A3
/* gearbox */
#define GEAR_RATIO 10
/* */
#define ONE_REVOLUTION STEP_PER_REVOLUTION*GEAR_RATIO

/* timer */
#define PERIOD_US_1 1000
#define PERIOD_US_2  500
