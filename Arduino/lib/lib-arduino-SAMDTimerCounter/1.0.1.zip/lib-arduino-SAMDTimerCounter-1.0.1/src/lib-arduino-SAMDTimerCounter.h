#pragma once

#include "Arduino.h"
#include <functional>

#ifndef LIB_ARDUINO_SAMD_TIMERCOUNTER_H
#define LIB_ARDUINO_SAMD_TIMERCOUNTER_H


/*
 * *******************************************************************************
 * GLOBAL STRUCT 
 * *******************************************************************************
 */

typedef enum
{
  TIMER_TCC0 = 0,     // TCC0
  TIMER_TCC1 = 1,     // TCC1
  TIMER_TCC2 = 2,     // TCC2
  TIMER_TC3  = 3,     // TC3
  TIMER_TC4  = 4,     // TC4
  TIMER_TC5  = 5,     // TC5
  MAX_TIMER
} SAMDTimerNumber;

typedef enum
{
  TYPE_TCCx =  0,
  TYPE_TCx  =  1,
  TYPE_ERR  = -1
} SAMDTimerType;


static uint16_t TC_GCLK_ID[MAX_TIMER] = 
                { 
                  GCM_TCC0_TCC1, 
                  GCM_TCC0_TCC1, 
                  GCM_TCC2_TC3, 
                  GCM_TCC2_TC3, 
                  GCM_TC4_TC5, 
                  GCM_TC4_TC5 
                };

static IRQn_Type TIMER_IRQ[MAX_TIMER] =
                {
                  TCC0_IRQn,
                  TCC1_IRQn,
                  TCC2_IRQn,
                  TC3_IRQn ,
                  TC4_IRQn ,
                  TC5_IRQn
                };
  
 
typedef void (*SAMDTimerCallback)  ();


#define TCx        ((TcCount16*) timer_ptr_)
#define TCCx       ((Tcc*)       timer_ptr_)



/*
 * *******************************************************************************
 * SAMDTimerCounter 
 * *******************************************************************************
 */
class SAMDTimerCounter
{
  /*-------------------------------------------------------------------------------
   * Public
   */
  public:
    /* Constructor */
    SAMDTimerCounter(const SAMDTimerNumber &);    
    ~SAMDTimerCounter();
    /* Attributes */
    /* Methods */
    //void attachCallback(SAMDTimerCallback);
    void attachCallback(std::function<void()>);
    void setPeriod     (const int &);
    int  getPeriod     (void);
    bool start         (void);
    bool stop          (void);
    bool reset         (void);
    bool isBusy        (void);
    bool toggle        (void);

  /*-------------------------------------------------------------------------------
   * Private
   */
  private:
    /* Attributes */
    void*           timer_ptr_ = NULL;
    SAMDTimerNumber timer_num_;
    SAMDTimerType   timer_type_;
    int             period_;
    bool            busy_;
    bool            flag_;
    /* Methods */
    void setTimerType();
    void setTimerPtr();

    void setClockSource(void);

    void setPrescalerTCCx(void);
    void setPrescalerTCx (void);
    
    void setModeTCCx(void);
    void setModeTCx (void);
    
    void setPeriodTCCx(const int &);
    void setPeriodTCx (const int &);

    void enableTCCx(void);
    void enableTCx (void);

    void disableTCCx(void);
    void disableTCx (void);

    void resetTCCx(void);
    void resetTCx (void);
    
    void attachInterrupt(void);
    void detachInterrupt(void);

    bool begin(void);
  };

#endif    // LIB_ARDUINO_SAMD_TIMERCOUNTER_H
