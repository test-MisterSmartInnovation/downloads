/* stepper */
#define STEP_PER_REVOLUTION 200
/* rear right*/
//#define PIN_STEP A3
//#define PIN_DIR  A4
/* rear left */
//#define PIN_STEP D0
//#define PIN_DIR  D1
/* front left */
//#define PIN_STEP D2
//#define PIN_DIR  D3
/* front right */
#define PIN_STEP A1
#define PIN_DIR  A2
/* gearbox */
#define GEAR_RATIO 10
/* */
#define JOINT_REVOLUTION STEP_PER_REVOLUTION*GEAR_RATIO

/* timer */
#define PERIOD_MS  10

/* rad/s */
#define MAX_SPEED 314
#define MIN_SPEED 104
