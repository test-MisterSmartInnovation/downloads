#include "lib-arduino-StepperSpeedCtrl.h"

/*
 * *******************************************************************************
 * StepperSpeedCtrl
 * *******************************************************************************
 */

/*-------------------------------------------------------------------------------
 * Constructor Destructor
 */
StepperSpeedCtrl::StepperSpeedCtrl(StepperCtrl * stepper, SAMDTimerCounter * timer)
{
  this->stepper_ = stepper; /* stepper*/
  this->timer_   = timer  ; /* timer */
  /* */
  this->begin();
}

/*-------------------------------------------------------------------------------
 * Public
 */
bool StepperSpeedCtrl::setSpeed(int speed)
{
  /* set speed [rad/s] */
  this->speed_ = speed;
  /* compute period to relative speed [rad/s] */
  this->half_period_ = (this->k_rad_us_ / abs(speed));
  /* */
  return true;
}


int StepperSpeedCtrl::getSpeed(void)
{
  /* */
  return this->speed_;
}


bool StepperSpeedCtrl::setPosition(int position)
{
  this->stepper_->setStepNum(position / this->stepper_->getStepAngle());
  /* */
  return true;
}


int StepperSpeedCtrl::getPosition(void)
{
  this->position_ = this->stepper_->getStepNum() * this->stepper_->getStepAngle() * this->resolution_;
  /* */
  return this->position_;
}


int StepperSpeedCtrl::getPtrStepper(void)
{
  /* */
  return (int)this->stepper_;
}


int StepperSpeedCtrl::getPtrTimer(void)
{
  /* */
  return (int)this->timer_;
}


bool StepperSpeedCtrl::directSpeed(int speed)
{
  /* compute new speed */
  this->setSpeed(speed);
  /* set direction */
  (speed > 0) ? this->stepper_->setDirection(StepperCtrl::CCW) : this->stepper_->setDirection(StepperCtrl::CW);
  /* stop timer */
  stop_timer_ = true;
  /* */
  if (speed)
    this->speed();
  /* */
  return true;
}


/*-------------------------------------------------------------------------------
 * Private
 */
bool StepperSpeedCtrl::begin(void)
{
  /* set constants */
  this->k_rad_us_ = this->stepper_->getStepAngle() * 1000 * 1000 * 0.5;  
  /* increase resolution:
   * - rpm   30 => 3000
   * - rad/s pi => pi*100
   */
  this->k_rad_us_ = this->k_rad_us_ * this->resolution_;
  /* set timer */
//  this->timer_->attachCallback(callbackTimer);
  std::function<void()> ptr_callbacktimer = std::bind(&StepperSpeedCtrl::callbackTimer, this);
  this->timer_->attachCallback(ptr_callbacktimer);
  /* */
  return true;
}


bool StepperSpeedCtrl::startCondition(void)
{
  /* reset flags */
  this->stop_timer_  = false;
  this->start_timer_ = false;
  /* start condition */
  this->stepper_->pulseStep();
  /* set timer */
  this->timer_->setPeriod(this->half_period_);
  this->timer_->start();
  /* */
  return true;
}


void StepperSpeedCtrl::speed(void)
{
  /* wait until timer is not busy */
  if(this->timer_->isBusy())
    this->start_timer_ = true;
  else
    this->startCondition();
}


void StepperSpeedCtrl::callbackTimer(void)
{
  /* */
  if ((!this->stepper_->isBusy()) && this->stop_timer_)
    {
      this->timer_->stop();
      if (start_timer_)
        this->startCondition();
    }
  else
    this->stepper_->pulseStep();
  /* */  
};

