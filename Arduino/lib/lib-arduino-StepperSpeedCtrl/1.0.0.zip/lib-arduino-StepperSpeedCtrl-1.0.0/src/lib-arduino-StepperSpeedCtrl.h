#pragma once

#include "Arduino.h"
#include "lib-arduino-StepperCtrl.h"
#include "lib-arduino-SAMDTimerCounter.h"

#ifndef LIB_ARDUINO_STEPPER_SPEED_CTRL_H
#define LIB_ARDUINO_STEPPER_SPEED_CTRL_H


/*
 * *******************************************************************************
 * StepperSpeedCtrl
 * *******************************************************************************
 */
class StepperSpeedCtrl {
  /*-------------------------------------------------------------------------------
   * Public
   */
  public:
    /* Constructor */
    StepperSpeedCtrl(StepperCtrl *, SAMDTimerCounter *);
    /* Attributes */
    /* Methods */
    /* */
    bool setSpeed (int) ;
    int  getSpeed (void);
    /* */
    bool setPosition (int) ;
    int  getPosition (void);
    /* */
    int getPtrStepper(void);
    int getPtrTimer  (void);
    /* */
    bool directSpeed (int);

  /*-------------------------------------------------------------------------------
   * Private
   */
  private:
    /* Attributes ISR */
    StepperCtrl      * stepper_;
    SAMDTimerCounter * timer_  ;
    volatile bool      start_timer_;
    volatile bool      stop_timer_;
    /* Attributes */
    int  k_rad_us_    ; /* constant to convert rad to us */
    int  half_period_; /* us      */
    int  speed_      ; /* [rad/s] * 100 */
    int  position_   ; /* [rad]   */
    /* */
    int resolution_ = 100;
    /* Methods */
    bool begin (void);
    bool startCondition(void);
    void speed (void);
    /* callback */
    void callbackTimer(void);
  
};

#endif // LIB_ARDUINO_STEPPER_SPEED_CTRL_H