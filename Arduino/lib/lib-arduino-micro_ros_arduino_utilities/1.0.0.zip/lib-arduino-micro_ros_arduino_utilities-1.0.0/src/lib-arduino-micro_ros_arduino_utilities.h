#pragma once

#ifndef LIB_ARDUINO_MICRO_ROS_UTILITIES_H
#define LIB_ARDUINO_MICRO_ROS_UTILITIES_H


#include "Arduino.h"
#include <micro_ros_arduino.h>

/* import msgs types */
#ifndef MESSAGES_STRUCT
  #include <std_msgs/msg/int8.h>
  #include <std_msgs/msg/int32.h>
  /* struct subscriber 1 */
  #define SUB_1_MESSAGES_STRUCT std_msgs__msg__Int8
  #define SUB_1_MESSAGES_PKG    std_msgs
  #define SUB_1_MESSAGES_NAME   Int8
  /* struct publisher 1 */
  #define PUB_1_MESSAGES_STRUCT std_msgs__msg__Int32
  #define PUB_1_MESSAGES_PKG    std_msgs
  #define PUB_1_MESSAGES_NAME   Int32
  /* struct publisher 2*/
  #define PUB_2_MESSAGES_STRUCT std_msgs__msg__Int8
  #define PUB_2_MESSAGES_PKG    std_msgs
  #define PUB_2_MESSAGES_NAME   Int8
#endif


#include <stdio.h>
#include <rcl/rcl.h>
#include <rcl/error_handling.h>
#include <rclc/rclc.h>
#include <rclc/executor.h>


#define RCCHECK(fn)     { rcl_ret_t temp_rc = fn; if((temp_rc != RCL_RET_OK)){Node::errorLoop();}}
#define RCSOFTCHECK(fn) { rcl_ret_t temp_rc = fn; if((temp_rc != RCL_RET_OK)){}}


/*
 * ***************************************************************
 * Node
 * ***************************************************************
 */

class Node
{
  /*
  * Class to generate a simple subscribrer
  * required:
  *  - const char *node_name
  * Node(const char *node_name)
  */
  private:
    /* methods */
  public:
    /* attributes */
    rclc_executor_t executor_;
    rclc_support_t  support_;
    rcl_allocator_t allocator_;
    rcl_node_t      node_;
    size_t          num_handles_ = 1; 
    const char     *node_name_ ;
    /* methods */
    Node(const char*);
    ~Node();
    bool init();
    bool initExecutor();
    void errorLoop();
    void spin_some(int);
    void spin();
};


/*
 * ***************************************************************
 * Subscriber
 * ***************************************************************
 */
class Subscriber : public Node
{
  /*
  * Class to generate a simple subscribrer
  * required:
  *  - const char *node_name
  *  - const char *topic_name
  * Subscriber(const char *node_name, const char *topic_name)
  */
  private:
    /* attributes */
    rcl_subscription_t    subscriber_;
    SUB_1_MESSAGES_STRUCT msg_;
    const char            *topic_name_;
    /* methods */
  public:
    /* attributes */
    /* methods */
    Subscriber(const char*, const char*);
    ~Subscriber();
    bool begin();
    bool attachSubscriberCallback(rclc_subscription_callback_t);
};


/*
 * ***************************************************************
 * Publisher
 * ***************************************************************
 */
class Publisher : public Node
{
  /*
  * Class to generate a simple subscribrer
  * required:
  *  - const char *node_name
  *  - const char *topic_name
  * Publisher(const char *node_name, const char *topic_name)
  */
  private:
    /* attributes */
    rcl_publisher_t publisher_;
    const char      *topic_name_;
    rcl_timer_t     timer_; 
    unsigned int    timeout_;
    /* methods */
  public:
    /* attributes */
    /* methods */
    Publisher(const char*, const char*);
    ~Publisher();
    bool begin();
    bool setTimerCallback(const unsigned int timeout, rcl_timer_callback_t);
    bool attachTimerCallback(void);
    bool publish(const void *);
};



/*
 * ***************************************************************
 * Publishers
 * ***************************************************************
 */
class Publishers : public Node
{
  /*
  * Class to generate a simple subscribrer
  * required:
  *  - const char *node_name
  *  - const char *topic_name_1
  *  - const char *topic_name_2
  * Publishers(const char *node_name, const char *topic_name_1, const char *topic_name_2)
  */
  private:
    /* attributes */
    rcl_publisher_t publisher_1_;
    rcl_publisher_t publisher_2_;
    const char      *topic_name_1_;
    const char      *topic_name_2_;
    rcl_timer_t     timer_; 
    unsigned int    timeout_;
    /* methods */
  public:
    /* attributes */
    /* methods */
    Publishers(const char*, const char*, const char*);
    ~Publishers();
    bool begin();
    bool setTimerCallback(const unsigned int timeout, rcl_timer_callback_t);
    bool attachTimerCallback(void);
    bool publish_1(const void *);
    bool publish_2(const void *);
};



/*
 * ***************************************************************
 * Publisher & Subscriber
 * ***************************************************************
 */
class PubSub : public Node
{
  /*
  * Class to generate a simple subscribrer
  * required:
  *  - const char *node_name
  *  - const char *topic_name_pub
  *  - const char *topic_name_sub
  * Publisher(const char *node_name, const char *topic_name_pub, const char *topic_name_sub)
  */
  private:
    /* attributes */
    rcl_publisher_t       publisher_;
    rcl_subscription_t    subscriber_;
    SUB_1_MESSAGES_STRUCT msg_sub_;
    const char            *topic_name_pub_;
    const char            *topic_name_sub_;
    rcl_timer_t           timer_; 
    /* methods */
  public:
    /* attributes */
    /* methods */
    PubSub(const char*, const char*, const char*);
    ~PubSub();
    bool begin();
    /* Publisher */
    bool setTimerCallback(const unsigned int timeout, rcl_timer_callback_t);
    bool attachTimerCallback(void);
    bool publish(const void *);
    /* Subscriber */
    bool attachSubscriberCallback(rclc_subscription_callback_t);    
};




/*
 * ***************************************************************
 * Publishers & Subscriber
 * ***************************************************************
 */
class PubsSub : public Node
{
  /*
  * Class to generate a simple subscribrer
  * required:
  *  - const char *node_name
  *  - const char *topic_name_pub_1
  *  - const char *topic_name_pub_2
  *  - const char *topic_name_sub
  * Publisher(const char *node_name,
  *           const char *topic_name_pub_1,
  *           const char *topic_name_pub_2,
  *           const char *topic_name_sub)
  */
  private:
    /* attributes */
    rcl_publisher_t       publisher_1_;
    rcl_publisher_t       publisher_2_;
    rcl_subscription_t    subscriber_;
    SUB_1_MESSAGES_STRUCT msg_sub_;
    const char            *topic_name_pub_1_;
    const char            *topic_name_pub_2_;
    const char            *topic_name_sub_;
    rcl_timer_t           timer_; 
    /* methods */
  public:
    /* attributes */
    /* methods */
    PubsSub(const char*, const char*, const char*, const char*);
    ~PubsSub();
    bool begin();
    /* Publisher */
    bool setTimerCallback(const unsigned int timeout, rcl_timer_callback_t);
    bool attachTimerCallback(void);
    bool publish_1(const void *);
    bool publish_2(const void *);
    /* Subscriber */
    bool attachSubscriberCallback(rclc_subscription_callback_t);  
};

#endif // LIB_ARDUINO_MICRO_ROS_UTILITIES_H