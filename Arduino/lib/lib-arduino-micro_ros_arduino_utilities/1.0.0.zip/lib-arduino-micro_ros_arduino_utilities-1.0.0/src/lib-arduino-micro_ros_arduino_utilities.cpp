#include "lib-arduino-micro_ros_arduino_utilities.h"

/*
 * ***************************************************************
 * Node
 * ***************************************************************
 */
Node::Node(const char *node_name)
{
  this->node_name_  = node_name;
}


Node::~Node() {}


bool Node::init()
{
  set_microros_transports();
  /* */
  this->allocator_ = rcl_get_default_allocator();
  /* create init_options */
  RCCHECK(rclc_support_init(&this->support_, 0, NULL, &this->allocator_));
  /* create node */
  RCCHECK(rclc_node_init_default(&this->node_, this->node_name_, "", &this->support_));
  /* */
  return true;
}

bool Node::initExecutor()
{
  RCCHECK(rclc_executor_init(&this->executor_, &this->support_.context, this->num_handles_, &this->allocator_));
  /* */
  return true;
}


void Node::errorLoop(){
  while(1){
    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
    delay(100);
  }
}


void Node::spin_some(int time)
{
  RCCHECK(rclc_executor_spin_some(&this->executor_, RCL_MS_TO_NS(time)));
}


void Node::spin()
{
  RCCHECK(rclc_executor_spin(&this->executor_));
}



/*
 * ***************************************************************
 * Subscriber
 * ***************************************************************
 */
Subscriber::Subscriber(const char *node_name, const char *topic_name) : Node(node_name)
{
  this->topic_name_ = topic_name;
}


Subscriber::~Subscriber() {}


bool Subscriber::begin()
{
  this->init();
  /* start subscriber */
  RCCHECK(rclc_subscription_init_default(
    &this->subscriber_,
    &this->node_,
    ROSIDL_GET_MSG_TYPE_SUPPORT(SUB_1_MESSAGES_PKG, msg, SUB_1_MESSAGES_NAME),
    this->topic_name_));
  /* start executor */
  this->initExecutor();
  /* */
  return true;
}


bool Subscriber::attachSubscriberCallback(rclc_subscription_callback_t callback)
{  
  RCCHECK(rclc_executor_add_subscription(&this->executor_, &this->subscriber_, &this->msg_, callback, ON_NEW_DATA));
  /* */
  return true;
}



/*
 * ***************************************************************
 * Publisher
 * ***************************************************************
 */
Publisher::Publisher(const char *node_name, const char *topic_name) : Node(node_name)
{
  this->topic_name_ = topic_name;
}


Publisher::~Publisher() {}


bool Publisher::begin()
{
  this->init();
  /* start publisher */
  RCCHECK(rclc_publisher_init_default(
    &this->publisher_,
    &this->node_,
    ROSIDL_GET_MSG_TYPE_SUPPORT(PUB_1_MESSAGES_PKG, msg, PUB_1_MESSAGES_NAME),
    this->topic_name_));
  /* start executor */
  this->initExecutor();
  /* */
  return true;
}


bool Publisher::setTimerCallback(const unsigned int timeout, rcl_timer_callback_t callback)
{
    /* create timer */
  RCCHECK(rclc_timer_init_default(
    &this->timer_,
    &this->support_,
    RCL_MS_TO_NS(timeout),
    callback));
  /* */
  return true;
}


bool Publisher::attachTimerCallback(void)
{  
  RCCHECK(rclc_executor_add_timer(&this->executor_, &this->timer_));
  /* trigger when handle 'timer' is ready */
  RCCHECK(rclc_executor_set_trigger(&this->executor_, rclc_executor_trigger_one, &this->timer_));
  /* */
  return true;
}


bool Publisher::publish(const void *msg)
{
  RCSOFTCHECK(rcl_publish(&this->publisher_, msg, NULL));
  /* */
  return true;
}



/*
 * ***************************************************************
 * Publishers
 * ***************************************************************
 */
Publishers::Publishers(const char *node_name, const char *topic_name_1, const char *topic_name_2) : Node(node_name)
{
  this->topic_name_1_ = topic_name_1;
  this->topic_name_2_ = topic_name_2;
}


Publishers::~Publishers() {}


bool Publishers::begin()
{
  this->init();
  /* start publisher 1 */
  RCCHECK(rclc_publisher_init_default(
    &this->publisher_1_,
    &this->node_,
    ROSIDL_GET_MSG_TYPE_SUPPORT(PUB_1_MESSAGES_PKG, msg, PUB_1_MESSAGES_NAME),
    this->topic_name_1_));
  /* start publisher 2 */
  RCCHECK(rclc_publisher_init_default(
    &this->publisher_2_,
    &this->node_,
    ROSIDL_GET_MSG_TYPE_SUPPORT(PUB_2_MESSAGES_PKG, msg, PUB_2_MESSAGES_NAME),
    this->topic_name_2_));
  /* start executor */
  this->initExecutor();
  /* */
  return true;
}


bool Publishers::setTimerCallback(const unsigned int timeout, rcl_timer_callback_t callback)
{
  /* create timer */
  RCCHECK(rclc_timer_init_default(
    &this->timer_,
    &this->support_,
    RCL_MS_TO_NS(timeout),
    callback));
  /* */
  return true;
}


bool Publishers::attachTimerCallback(void)
{  
  RCCHECK(rclc_executor_add_timer(&this->executor_, &this->timer_));
  /* trigger when handle 'timer' is ready */
  RCCHECK(rclc_executor_set_trigger(&this->executor_, rclc_executor_trigger_one, &this->timer_));
  /* */
  return true;
}


bool Publishers::publish_1(const void *msg)
{
  RCSOFTCHECK(rcl_publish(&this->publisher_1_, msg, NULL));
  /* */
  return true;
}

bool Publishers::publish_2(const void *msg)
{
  RCSOFTCHECK(rcl_publish(&this->publisher_2_, msg, NULL));
  /* */
  return true;
}



/*
 * ***************************************************************
 * Publisher & Subscriber
 * ***************************************************************
 */
PubSub::PubSub(const char *node_name, const char *topic_name_pub, const char *topic_name_sub) : Node(node_name)
{
  this->topic_name_pub_ = topic_name_pub;
  this->topic_name_sub_ = topic_name_sub;
  /* override num handles */
  this->num_handles_ = 2;
}


PubSub::~PubSub() {}


bool PubSub::begin()
{
  this->init();
  /* create subscriber */
  RCCHECK(rclc_subscription_init_default(
    &this->subscriber_,
    &this->node_,
    ROSIDL_GET_MSG_TYPE_SUPPORT(SUB_1_MESSAGES_PKG, msg, SUB_1_MESSAGES_NAME),
    this->topic_name_sub_));
  /* create publisher */
  RCCHECK(rclc_publisher_init_default(
    &this->publisher_,
    &this->node_,
    ROSIDL_GET_MSG_TYPE_SUPPORT(PUB_1_MESSAGES_PKG, msg, PUB_1_MESSAGES_NAME),
    this->topic_name_pub_));
  /* */
  return true;
}


bool PubSub::setTimerCallback(const unsigned int timeout, rcl_timer_callback_t callback)
{
  /* create timer */
  RCCHECK(rclc_timer_init_default(
    &this->timer_,
    &this->support_,
    RCL_MS_TO_NS(timeout),
    callback));
  /* */
  return true;
}


bool PubSub::attachTimerCallback(void)
{  
  RCCHECK(rclc_executor_add_timer(&this->executor_, &this->timer_));
  /* trigger when handle 'timer' is ready */
  RCCHECK(rclc_executor_set_trigger(&this->executor_, rclc_executor_trigger_one, &this->timer_));
  /* */
  return true;
}


bool PubSub::publish(const void *msg)
{
  RCSOFTCHECK(rcl_publish(&this->publisher_, msg, NULL));
  /* */
  return true;
}


bool PubSub::attachSubscriberCallback(rclc_subscription_callback_t callback)
{  
  RCCHECK(rclc_executor_add_subscription(&this->executor_, &this->subscriber_, &this->msg_sub_, callback, ALWAYS));
  /* */
  return true;
}



/*
 * ***************************************************************
 * Publishers & Subscriber
 * ***************************************************************
 */
PubsSub::PubsSub(const char *node_name,
               const char *topic_name_pub_1,
               const char *topic_name_pub_2, 
               const char *topic_name_sub) : Node(node_name)
{
  this->topic_name_pub_1_ = topic_name_pub_1;
  this->topic_name_pub_2_ = topic_name_pub_2;
  this->topic_name_sub_ = topic_name_sub;
  /* override num handles */
  this->num_handles_ = 2;
}


PubsSub::~PubsSub() {}


bool PubsSub::begin()
{
  this->init();
  /* create subscriber */
  RCCHECK(rclc_subscription_init_default(
    &this->subscriber_,
    &this->node_,
    ROSIDL_GET_MSG_TYPE_SUPPORT(SUB_1_MESSAGES_PKG, msg, SUB_1_MESSAGES_NAME),
    this->topic_name_sub_));
  /* create publisher 1 */
  RCCHECK(rclc_publisher_init_default(
    &this->publisher_1_,
    &this->node_,
    ROSIDL_GET_MSG_TYPE_SUPPORT(PUB_1_MESSAGES_PKG, msg, PUB_1_MESSAGES_NAME),
    this->topic_name_pub_1_));
  /* create publisher 2 */
  RCCHECK(rclc_publisher_init_default(
    &this->publisher_2_,
    &this->node_,
    ROSIDL_GET_MSG_TYPE_SUPPORT(PUB_2_MESSAGES_PKG, msg, PUB_2_MESSAGES_NAME),
    this->topic_name_pub_2_));
  /* */
  return true;
}


bool PubsSub::setTimerCallback(const unsigned int timeout, rcl_timer_callback_t callback)
{
    /* create timer */
  RCCHECK(rclc_timer_init_default(
    &this->timer_,
    &this->support_,
    RCL_MS_TO_NS(timeout),
    callback));
  /* */
  return true;
}


bool PubsSub::attachTimerCallback(void)
{  
  RCCHECK(rclc_executor_add_timer(&this->executor_, &this->timer_));
  /* trigger when handle 'timer' is ready */
  RCCHECK(rclc_executor_set_trigger(&this->executor_, rclc_executor_trigger_one, &this->timer_));
  /* */
  return true;
}


bool PubsSub::publish_1(const void *msg)
{
  RCSOFTCHECK(rcl_publish(&this->publisher_1_, msg, NULL));
  /* */
  return true;
}


bool PubsSub::publish_2(const void *msg)
{
  RCSOFTCHECK(rcl_publish(&this->publisher_2_, msg, NULL));
  /* */
  return true;
}


bool PubsSub::attachSubscriberCallback(rclc_subscription_callback_t callback)
{  
  RCCHECK(rclc_executor_add_subscription(&this->executor_, &this->subscriber_, &this->msg_sub_, callback, ALWAYS));
  /* */
  return true;
}