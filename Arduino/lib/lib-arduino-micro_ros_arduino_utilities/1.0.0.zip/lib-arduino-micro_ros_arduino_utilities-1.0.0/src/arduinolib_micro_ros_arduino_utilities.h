#pragma once

#ifndef ARDUINOLIB_MICRO_ROS_UTILITIES_H
#define ARDUINOLIB_MICRO_ROS_UTILITIES_H



#include "Arduino.h"
#include <micro_ros_arduino.h>


/* work around */
#include "setting.h"

#include <stdio.h>
#include <rcl/rcl.h>
#include <rcl/error_handling.h>
#include <rclc/rclc.h>
#include <rclc/executor.h>


#define RCCHECK(fn)     { rcl_ret_t temp_rc = fn; if((temp_rc != RCL_RET_OK)){Node::errorLoop();}}
#define RCSOFTCHECK(fn) { rcl_ret_t temp_rc = fn; if((temp_rc != RCL_RET_OK)){}}


/*
 * ***************************************************************
 * Node
 * ***************************************************************
 */

class Node
{
  /*
  * Class to generate a simple subscribrer
  * required:
  *  - const char *node_name
  * Node(const char *node_name)
  */
  /*-----------------------------------------------------------
   * Public
   */
  public:
    /* methods */
    Node(const char*);
    ~Node();
    bool init        (void);
    bool initExecutor(void);
    void errorLoop   (void);
    void spin_some   (int) ;
    void spin        (void);
    /* attributes */
    rclc_executor_t  executor_;
    rclc_support_t   support_;
    rcl_allocator_t  allocator_;
    rcl_node_t       node_;
    size_t           num_handles_ = 1; 
    const char      *node_name_ ;
  /*-----------------------------------------------------------
   * Private
   */
  private:
    /* methods */
    /* attributes */
};


/*
 * ***************************************************************
 * Subscriber
 * ***************************************************************
 */
class Subscriber : public Node
{
  /*
  * Class to generate a simple subscribrer
  * required:
  *  - const char *node_name
  *  - const char *topic_name
  * Subscriber(const char *node_name, const char *topic_name)
  */
  /*-----------------------------------------------------------
   * Public
   */
  public:
    /* methods */
    Subscriber(const char*, const char*);
    ~Subscriber();
    bool begin();
    bool attachSubscriberCallback(rclc_subscription_callback_t);
    /* attributes */
  /*-----------------------------------------------------------
   * Private
   */
  private:
    /* methods */
    /* attributes */
    rcl_subscription_t     subscriber_;
    SUB_1_MESSAGES_STRUCT  msg_;
    const char            *topic_name_;
};


/*
 * ***************************************************************
 * Publisher
 * ***************************************************************
 */
class Publisher : public Node
{
  /*
  * Class to generate a simple subscribrer
  * required:
  *  - const char *node_name
  *  - const char *topic_name
  * Publisher(const char *node_name, const char *topic_name)
  */
  /*-----------------------------------------------------------
   * Public
   */
  public:
    /* methods */
    Publisher(const char*, const char*);
    ~Publisher();
    bool begin              (void);
    bool setTimerCallback   (const unsigned int, rcl_timer_callback_t);
    bool attachTimerCallback(void);
    bool publish            (const void *);
    /* attributes */
  /*-----------------------------------------------------------
   * Private
   */
  private:
    /* methods */
    /* attributes */
    rcl_publisher_t  publisher_;
    rcl_timer_t      timer_;
    const char      *topic_name_;
    unsigned int     timeout_;
};



/*
 * ***************************************************************
 * Publishers
 * ***************************************************************
 */
class Publishers : public Node
{
  /*
  * Class to generate a simple subscribrer
  * required:
  *  - const char *node_name
  *  - const char *topic_name_1
  *  - const char *topic_name_2
  * Publishers(const char *node_name, const char *topic_name_1, const char *topic_name_2)
  */
  /*-----------------------------------------------------------
   * Public
   */
  public:
    /* methods */
    Publishers(const char*, const char*, const char*);
    ~Publishers();
    bool begin              (void);
    bool setTimerCallback   (const unsigned int, rcl_timer_callback_t);
    bool attachTimerCallback(void);
    bool publish_1          (const void *);
    bool publish_2          (const void *);
    /* attributes */
  /*-----------------------------------------------------------
   * Private
   */
  private:
    /* methods */
    /* attributes */
    rcl_publisher_t  publisher_1_;
    rcl_publisher_t  publisher_2_;
    rcl_timer_t      timer_; 
    const char      *topic_name_1_;
    const char      *topic_name_2_;
    unsigned int     timeout_;
};



/*
 * ***************************************************************
 * Publisher & Subscriber
 * ***************************************************************
 */
class PubSub : public Node
{
  /*
  * Class to generate a simple subscribrer
  * required:
  *  - const char *node_name
  *  - const char *topic_name_pub
  *  - const char *topic_name_sub
  * PubSub(const char *node_name, const char *topic_name_pub, const char *topic_name_sub)
  */
  /*-----------------------------------------------------------
   * Public
   */
  public:
    /* methods */
    PubSub(const char*, const char*, const char*);
    ~PubSub();
    bool begin                   (void);
    bool setTimerCallback        (const unsigned int, rcl_timer_callback_t); /* publisher */
    bool attachTimerCallback     (void);         /* publisher */
    bool publish                 (const void *); /* publisher */
    bool attachSubscriberCallback(rclc_subscription_callback_t); /* subscriber */
    /* attributes */
  /*-----------------------------------------------------------
   * Private
   */
  private:
    /* methods */
    /* attributes */
    rcl_publisher_t        publisher_;
    rcl_subscription_t     subscriber_;
    rcl_timer_t            timer_;
    SUB_1_MESSAGES_STRUCT  msg_sub_;
    const char            *topic_name_pub_;
    const char            *topic_name_sub_;
};




/*
 * ***************************************************************
 * Publishers & Subscriber
 * ***************************************************************
 */
class PubsSub : public Node
{
  /*
  * Class to generate a simple subscribrer
  * required:
  *  - const char *node_name
  *  - const char *topic_name_pub_1
  *  - const char *topic_name_pub_2
  *  - const char *topic_name_sub
  * PubsSub(const char *node_name,
  *           const char *topic_name_pub_1,
  *           const char *topic_name_pub_2,
  *           const char *topic_name_sub)
  */
  /*-----------------------------------------------------------
   * Public
   */
  public:
    /* methods */
    PubsSub(const char*, const char*, const char*, const char*);
    ~PubsSub();
    bool begin                   (void);
    bool setTimerCallback        (const unsigned int, rcl_timer_callback_t); /* publisher */
    bool attachTimerCallback     (void);         /* publisher */
    bool publish_1               (const void *); /* publisher */
    bool publish_2               (const void *); /* publisher */
    bool attachSubscriberCallback(rclc_subscription_callback_t); /* subscriber */
    /* attributes */
  /*-----------------------------------------------------------
   * Private
   */
  private:
    /* methods */
    /* attributes */
    rcl_publisher_t       publisher_1_;
    rcl_publisher_t       publisher_2_;
    rcl_subscription_t    subscriber_;
    rcl_timer_t           timer_; 
    SUB_1_MESSAGES_STRUCT msg_sub_;
    const char            *topic_name_pub_1_;
    const char            *topic_name_pub_2_;
    const char            *topic_name_sub_;
};

#endif // ARDUINOLIB_MICRO_ROS_UTILITIES_H