#pragma once

/***********************************/
/* MESSAGES CONF*/
/***********************************/

#include <micro_ros_arduino.h>
#include <std_msgs/msg/float32.h>
#include <std_msgs/msg/float64.h>

#define MESSAGES_STRUCT

/* Publisher msgs type */
#define PUB_1_MESSAGES_STRUCT std_msgs__msg__Float64
#define PUB_1_MESSAGES_PKG    std_msgs
#define PUB_1_MESSAGES_NAME   Float64
#define PUB_2_MESSAGES_STRUCT std_msgs__msg__Float32
#define PUB_2_MESSAGES_PKG    std_msgs
#define PUB_2_MESSAGES_NAME   Float32

/* Subscriber msgs type */
#define SUB_1_MESSAGES_STRUCT std_msgs__msg__Float32
#define SUB_1_MESSAGES_PKG    std_msgs
#define SUB_1_MESSAGES_NAME   Float32

/* task period Publisher Subscriber */
#define PERIOD_MS 10

