#include <std_msgs/msg/int8.h>
#include <std_msgs/msg/int32.h>
#include <ros2lib_stepper_msgs/msg/stepper.h>
#include <ros2lib_4stepper_msgs/msg/steppers.h>

/* struct subscriber 1 */
#define SUB_1_MESSAGES_STRUCT ros2lib_4stepper_msgs__msg__Steppers
#define SUB_1_MESSAGES_PKG    ros2lib_4stepper_msgs
#define SUB_1_MESSAGES_NAME   Steppers
/* struct publisher 1 */
#define PUB_1_MESSAGES_STRUCT ros2lib_4stepper_msgs__msg__Steppers
#define PUB_1_MESSAGES_PKG    ros2lib_4stepper_msgs
#define PUB_1_MESSAGES_NAME   Steppers
/* struct publisher 2*/
#define PUB_2_MESSAGES_STRUCT std_msgs__msg__Int8
#define PUB_2_MESSAGES_PKG    std_msgs
#define PUB_2_MESSAGES_NAME   Int8


