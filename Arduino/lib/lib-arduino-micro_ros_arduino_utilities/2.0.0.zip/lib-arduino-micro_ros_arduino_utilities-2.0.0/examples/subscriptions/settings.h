#pragma once
/***********************************/
/* micro ROS CONF*/
/***********************************/
#include <std_msgs/msg/int8.h>
#include <std_msgs/msg/float32.h>
/* MESSAGE STRUCT INT */
#define MESSAGES_TYPE_INT_STRUCT   std_msgs__msg__Int8
#define MESSAGES_TYPE_INT_PKG      std_msgs
#define MESSAGES_TYPE_INT_NAME     Int8
/* MESSAGE STRUCT FLOAT */
#define MESSAGES_TYPE_FLOAT_STRUCT std_msgs__msg__Float32
#define MESSAGES_TYPE_FLOAT_PKG    std_msgs
#define MESSAGES_TYPE_FLOAT_NAME   Float32
/* period Node micro-ROS */
#define PERIOD_MS 10