#pragma once
/***********************************/
/* micro ROS CONF*/
/***********************************/
#include <std_msgs/msg/int8.h>
#include <std_msgs/msg/float64.h>
/* MESSAGE STRUCT INT */
#define MESSAGES_TYPE_INT_STRUCT   std_msgs__msg__Int8
#define MESSAGES_TYPE_INT_PKG      std_msgs
#define MESSAGES_TYPE_INT_NAME     Int8
/* MESSAGE STRUCT FLOAT */
#define MESSAGES_TYPE_FLOAT_STRUCT std_msgs__msg__Float64
#define MESSAGES_TYPE_FLOAT_PKG    std_msgs
#define MESSAGES_TYPE_FLOAT_NAME   Float64
/* period Node micro-ROS */
#define PERIOD_MS 10