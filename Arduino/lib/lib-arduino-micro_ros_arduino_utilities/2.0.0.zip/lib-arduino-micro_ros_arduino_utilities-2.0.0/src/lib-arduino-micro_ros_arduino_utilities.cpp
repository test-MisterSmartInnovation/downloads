#include "lib-arduino-micro_ros_arduino_utilities.h"

/*
 * ***************************************************************
 * Node
 * ***************************************************************
 */
Node::Node(const char *node_name)
{
  this->node_name_  = node_name;
}


Node::~Node() {}


bool Node::init()
{
  /* */
  this->num_handles_ = MAX_PUBLISHERS + MAX_SUBSCRIPTIONS;
  /* */
  set_microros_transports();
  /* */
  this->allocator_ = rcl_get_default_allocator();
  /* create init_options */
  RCCHECK(rclc_support_init(&this->support_, 0, NULL, &this->allocator_));
  /* create node */
  RCCHECK(rclc_node_init_default(&this->node_, this->node_name_, "", &this->support_));
  /* */
  return true;
}

bool Node::initExecutor()
{
  RCCHECK(rclc_executor_init(&this->executor_, &this->support_.context, this->num_handles_, &this->allocator_));
  /* */
  return true;
}


void Node::errorLoop(){
  while(1){
    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
    delay(100);
  }
}


void Node::spin_some(int time)
{
  RCCHECK(rclc_executor_spin_some(&this->executor_, RCL_MS_TO_NS(time)));
}


void Node::spin()
{
  RCCHECK(rclc_executor_spin(&this->executor_));
}


bool Node::begin()
{
  /* */
  this->init();
  /* */
  return true;
}


bool Node::setPublisher(int index, const char * publisher_name, const rosidl_message_type_support_t * type_support)
{
  /* */
  this->publisher_name_[index] = publisher_name;
  /* create publisher i */
  RCCHECK(rclc_publisher_init_default(
    &this->publishers_[index],
    &this->node_,
    type_support,
    //ROSIDL_GET_MSG_TYPE_SUPPORT(PUB_MESSAGES_PKG, msg, PUB_MESSAGES_NAME),
    this->publisher_name_[index]));
  
}


bool Node::setSubscription(int index, const char * subscription_name, const rosidl_message_type_support_t * type_support)
{
  /* */
  this->subscription_name_[index] = subscription_name;
  /* create subscriber i*/
  RCCHECK(rclc_subscription_init_default(
    &this->subscriptions_[index],
    &this->node_,
    type_support,
    //ROSIDL_GET_MSG_TYPE_SUPPORT(SUB_MESSAGES_PKG, msg, SUB_MESSAGES_NAME),
    this->subscription_name_[index]));
  
}

bool Node::setTimerCallback(const unsigned int timeout, rcl_timer_callback_t callback)
{
    /* create timer */
  RCCHECK(rclc_timer_init_default(
    &this->timer_,
    &this->support_,
    RCL_MS_TO_NS(timeout),
    callback));
  /* */
  return true;
}


bool Node::attachTimerCallback(void)
{  
  RCCHECK(rclc_executor_add_timer(&this->executor_, &this->timer_));
  /* trigger when handle 'timer' is ready */
  RCCHECK(rclc_executor_set_trigger(&this->executor_, rclc_executor_trigger_one, &this->timer_));
  /* */
  return true;
}


bool Node::publish(int index, const void *msg)
{
  RCSOFTCHECK(rcl_publish(&this->publishers_[index], msg, NULL));
  /* */
  return true;
}


bool Node::attachSubscriptionCallback(int index, rclc_subscription_callback_t callback, rclc_executor_handle_invocation_t invocation)
{  
  RCCHECK(rclc_executor_add_subscription(&this->executor_, &this->subscriptions_[index], &this->msg_subs_[index], callback, invocation));
  /* */
  return true;
}