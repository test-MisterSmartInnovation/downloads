#include "lib-arduino-micro_ros_arduino_utilities.h"

/*
 * ***************************************************************
 * Node
 * ***************************************************************
 */
Node::Node(const char *node_name)
{
  /* */
  this->node_name_  = node_name;
  /* */
  this->num_handles_ = MAX_PUBLISHERS + MAX_SUBSCRIPTIONS;
  /* handle pin here */
  digitalWrite(PIN_RESET, HIGH);
  pinMode(PIN_RESET, OUTPUT);
  pinMode(LED_BUILTIN, OUTPUT);
}


Node::~Node() {}


bool Node::checkConnection(void)
{
  /* */
  set_microros_transports();
  /* */
  delay(2000);
  /* */
  this->allocator_ = rcl_get_default_allocator();
  /* create init_options */
  RCCHECK(rclc_support_init(&this->support_, 0, NULL, &this->allocator_));
  /* */
  return true;
}


bool Node::init(void)
{
  /* create node */
  RCCHECK(rclc_node_init_default(&this->node_, this->node_name_, "", &this->support_));
  /* */
  return true;
}

bool Node::initExecutor()
{
  /* */
  RCCHECK(rclc_executor_init(&this->executor_, &this->support_.context, this->num_handles_, &this->allocator_));
  /* */
  return true;
}


void Node::errorLoop()
{
  for(int i = 0; i < 100; i++)
  {
    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
    delay(100);
  }
  digitalWrite(PIN_RESET, !digitalRead(PIN_RESET));
}


bool Node::spin_some(int time)
{
  /* */
  // check_connection = RCL_RET_OK && rclc_executor_spin_some(&this->executor_, RCL_MS_TO_NS(time));
  RCCHECK(rclc_executor_spin_some(&this->executor_, RCL_MS_TO_NS(time)));
  /* */
  return true;
}


bool Node::spin()
{
  /* */
  // check_connection = RCL_RET_OK && rclc_executor_spin(&this->executor_);
  RCCHECK(rclc_executor_spin(&this->executor_));
  /* */
  return true;
}


bool Node::begin()
{
  /* */
  return this->init();
}


bool Node::setPublisher(int index, const char * publisher_name, const rosidl_message_type_support_t * type_support)
{
  /* */
  this->publisher_name_[index] = publisher_name;
  /* create publisher i */
  RCCHECK(rclc_publisher_init_default(&this->publishers_[index], &this->node_, type_support, this->publisher_name_[index]));
  /* */
  return true;
}


bool Node::setSubscription(int index, const char * subscription_name, const rosidl_message_type_support_t * type_support)
{
  /* */
  this->subscription_name_[index] = subscription_name;
  /* create subscriber i*/
  // check_connection = RCL_RET_OK && rclc_subscription_init_default(&this->subscriptions_[index], &this->node_, type_support, this->subscription_name_[index]);
  RCCHECK(rclc_subscription_init_default(&this->subscriptions_[index], &this->node_, type_support, this->subscription_name_[index]));
  /* */
  return true;
}

bool Node::setTimerCallback(const unsigned int timeout, rcl_timer_callback_t callback)
{
  /* create timer */
  RCCHECK(rclc_timer_init_default(&this->timer_, &this->support_, RCL_MS_TO_NS(timeout), callback));
  /* */
  return true;
}


bool Node::attachTimerCallback(void)
{
  /* */
  RCCHECK(rclc_executor_add_timer(&this->executor_, &this->timer_));
  /* trigger when handle 'timer' is ready */
  RCCHECK(rclc_executor_set_trigger(&this->executor_, rclc_executor_trigger_one, &this->timer_));
  /* */
  return true;
}


bool Node::publish(int index, const void *msg)
{
  /* */
  RCCHECK(rcl_publish(&this->publishers_[index], msg, NULL));
  /* */
  return true;
}


bool Node::attachSubscriptionCallback(int index, rclc_subscription_callback_t callback, rclc_executor_handle_invocation_t invocation)
{
  /* */
  RCCHECK(rclc_executor_add_subscription(&this->executor_, &this->subscriptions_[index], &this->msg_subs_[index], callback, invocation));
  /* */
  return true;
}