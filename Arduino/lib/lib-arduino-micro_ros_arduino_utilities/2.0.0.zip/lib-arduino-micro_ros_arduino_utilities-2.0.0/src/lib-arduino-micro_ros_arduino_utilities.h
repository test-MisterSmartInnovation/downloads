#pragma once

#ifndef LIB_ARDUINO_MICRO_ROS_UTILITIES_H
#define LIB_ARDUINO_MICRO_ROS_UTILITIES_H

#include <stdio.h>

#include "Arduino.h"
#include <micro_ros_arduino.h>

#include <rcl/rcl.h>
#include <rcl/error_handling.h>
#include <rclc/rclc.h>
#include <rclc/executor.h>


#define RCCHECK(fn)     { rcl_ret_t temp_rc = fn; if((temp_rc != RCL_RET_OK)){Node::errorLoop();}}
#define RCSOFTCHECK(fn) { rcl_ret_t temp_rc = fn; if((temp_rc != RCL_RET_OK)){}}

/* max publisher subcription for arm 32bit cortex m0*/
#define MAX_PUBLISHERS    4
#define MAX_SUBSCRIPTIONS 4

#define PIN_RESET D12

/*
 * ***************************************************************
 * Node
 * ***************************************************************
 */

class Node
{
  /*
  * Class to generate a simple subscribrer
  * required:
  *  - const char *node_name
  * Node(const char *node_name)
  */
  private:
    /* attributes node */
    rclc_executor_t executor_   ;
    rclc_support_t  support_    ;
    rcl_allocator_t allocator_  ;
    rcl_node_t      node_       ;
    size_t          num_handles_; 
    const char     *node_name_  ;
    /* attributes pub sub */
    rcl_publisher_t         publishers_       [MAX_PUBLISHERS   ];
    rcl_subscription_t      subscriptions_    [MAX_SUBSCRIPTIONS];
    void *                  msg_subs_         [MAX_SUBSCRIPTIONS];
    const char            * publisher_name_   [MAX_PUBLISHERS   ];
    const char            * subscription_name_[MAX_SUBSCRIPTIONS];
    rcl_timer_t             timer_            ;
    /* methods */
  public:
    /* attributes */
    /* methods */
    Node(const char*);
    ~Node();
    bool checkConnection(void);
    bool init(void);
    bool initExecutor(void);
    void errorLoop(void);
    bool spin_some(int);
    bool spin(void);
    /* methods pub sub */
    bool begin(void);
    /* Publisher */
    bool setPublisher(int, const char *, const rosidl_message_type_support_t *);
    bool setTimerCallback(const unsigned int, rcl_timer_callback_t);
    bool attachTimerCallback(void);
    bool publish(int, const void *);
    /* Subscriber */
    bool setSubscription(int, const char *, const rosidl_message_type_support_t *);
    bool attachSubscriptionCallback(int, rclc_subscription_callback_t, rclc_executor_handle_invocation_t); 
};


#endif // LIB_ARDUINO_MICRO_ROS_UTILITIES_H