// generated from rosidl_generator_c/resource/idl.h.em
// with input from example_interfaces:msg/Empty.idl
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__MSG__EMPTY_H_
#define EXAMPLE_INTERFACES__MSG__EMPTY_H_

#include "example_interfaces/msg/detail/empty__struct.h"
#include "example_interfaces/msg/detail/empty__functions.h"
#include "example_interfaces/msg/detail/empty__type_support.h"

#endif  // EXAMPLE_INTERFACES__MSG__EMPTY_H_
