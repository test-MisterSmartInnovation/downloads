# Misterino Core for SAMD21 CPU

This repository contains the source code and configuration files of the Misterino Core
for Atmel's SAMD21 processor (used on the Misterino Zero).

## Installation on Arduino IDE

This core is available as a package in the Arduino IDE cores manager.
Just open the "Boards Manager" and install the package called:

"Misterino SAMD Boards (32-bit ARM Cortex-M0+)"
