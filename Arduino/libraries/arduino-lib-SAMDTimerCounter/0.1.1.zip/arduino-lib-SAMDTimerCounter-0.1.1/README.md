# SAMDTimerCounter
This library allows you to enable timer interrupt with SAMD mcu arch.
